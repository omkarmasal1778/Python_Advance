
#Python Tuples
'''

It is a collection of data of different data types.
we can not change the value of tuples.
It is used to store tuple of values.
A tuple is created using parentheses.
Value of tuple can be accessed using index number.It always
 start from 0.




A tuple is a collection which is ordered and unchangeable.
Allow Duplicates



#Create a Tuple:

thistuple = ("apple", "banana", "cherry","apple")
print(thistuple)

tuple1 = ("apple", "banana", "cherry")
tuple2 = (1, 5, 7, 9, 3)
tuple3 = (True, False, False)
print(tuple3)
print(tuple1)



tuple1 = (67, 34.67, True, 40, "male")
print(tuple1)
print(type(tuple1))






thistuple = ("apple", "banana", "cherry")
print(thistuple[-1])


thistuple = ("apple", "banana", "cherry", "orange", "kiwi", "melon", "mango")
print(thistuple[3:5])


thistuple = ("apple", "banana", "cherry", "orange", "kiwi", "melon", "mango")
print(thistuple[:2])


thistuple = ("apple", "banana", "cherry", "orange", "kiwi", "melon", "mango")
print(thistuple[2:])



# Cannot change the elements stored as compared to lists
l1 = [1, 2, 3, 4, 5, 6, 7]
t1 = (1, 2, 3, 4, 5, 6, 7)

# Can change elements in list
l1[4] = 1
# Cannot change elements in tuple (Uncomment it to see the error)
#t1[4] = 1

print (l1)
print (t1)


#Update Tuples

#Change Tuple Values
fruit_tuple=("Apple","Orange","Mango")
print("Tuple before updation:",fruit_tuple)

fruit_list=list(fruit_tuple)       #convert tuple into list

fruit_list[1]="banana"             #update orange with banana

fruit_tuple=tuple(fruit_list)      #convert list into tuple
print("Tuple after updation:",fruit_tuple)






x = ("apple", "banana", "cherry")
y = list(x)
y[1] = "kiwi"
x = tuple(y)

print(x)

#Add Items
thistuple = ("apple", "banana", "cherry")
y = list(thistuple)
y.append("orange")
thistuple = tuple(y)
print(thistuple)


thistuple = ("apple", "banana", "cherry")
y = list(thistuple)
y.remove("apple")
thistuple = tuple(y)
print(thistuple)




thistuple = ("apple", "banana", "cherry")
print(thistuple)
del thistuple



#Unpack Tuples
#Unpacking a tuple:

fruits = ("apple", "banana", "cherry")
(green, yellow, red) = fruits

print(green)
print(yellow)
print(red)



#Assign the rest of the values as a list called "red":

fruits = ("apple", "banana", "cherry", "strawberry", "raspberry")

(green, yellow, *red) = fruits

print(green)
print(yellow)
print(red)


fruits = ("apple", "mango", "papaya", "pineapple", "cherry")

(green,*tropic,red) = fruits

print(green)
print(tropic)
print(red)





#Join Tuples
tuple1 = (5,6,7,8)
tuple2 = (1, 2, 3)

tuple3 = tuple1 + tuple2
print(tuple3)

'''
#Multiply the fruits tuple by 2:

fruits = ("apple", "banana", "cherry")

mytuple = fruits * 3

print(mytuple)



