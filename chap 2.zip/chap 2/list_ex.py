'''
li = [1,2,3,'a','b','c']

print(li)

name = ['Snowball', 'Chewy', 'Bubbles', 'Gruff']
animal = ['Cat', 'Dog', 'Fish', 'Goat']
age = [1, 2, 2, 6]
z = zip(name, animal, age)
for name,animal,age in z:
    print(f"{name} the {animal} is {age}")

x = [1]
print(id(x), ':', x)
x.append(5)
x.extend([6, 7])
print(id(x), ':', x)

pets = ['dog', 'cat', 'fish', 'fish', 'cat']
print(pets.count('fish'))


li = ['a', 'b', 'c', 'd', 'e']
print(len(li))


li = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]
print(li[2:16:2])


'''

li = [10, 1, 9, 2, 8, 3, 7, 4, 6, 5]
li.sort(reverse=True)
print(li)
