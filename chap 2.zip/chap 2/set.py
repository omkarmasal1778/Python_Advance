'''Set
Sets are used to store multiple items in a single variable.
It is an unordered collection of data of different data types.
Set is one of 4 built-in data types in Python used to store
collections of data, the other 3 are List, Tuple, and Dictionary,
all with different qualities and usage.

A set is a collection which is unordered, unchangeable*, and unindexed.

set does not contain duplicate data.

* Note: Set items are unchangeable, but you can remove items and
        add new items.

thisset = {"apple", "banana", 'cherry',"apple"}
print(thisset)


Set Items
Set items are unordered, unchangeable, and do
not allow duplicate values.

Unordered
Unordered means that the items in a set do not
have a defined order.

Set items can appear in a different order every time you use them,
and cannot be referred to by index or key.

Unchangeable
Set items are unchangeable, meaning that we cannot
change the items after the set has been created.

Once a set is created, you cannot change its items,
but you can remove items and add new items.




thisset = {"apple", "banana", "cherry", "apple"}
print(thisset)


Get the Length of a Set
To determine how many items a set has, use the len() method.

Example



thisset = {"apple", "banana", "cherry"}
print(len(thisset))



myset = {"apple", "banana", "cherry"}
print(type(myset))





Python - Access Set Items
Access Items
You cannot access items in a set by referring to an index or a key.

But you can loop through the set items using a for loop, or ask if 
a specified value is present in a set, by using the in keyword.

Example
Loop through the set, and print the values:

thisset = {"apple", "banana", "cherry"}

for x in thisset:
    print(x ,end=" ")




#Example
#Check if "banana" is present in the set:

thisset = {"apple", "banana", "cherry"}

print("banana" in thisset)


Add Items
Once a set is created, you cannot change its items, 
but you can add new items.

To add one item to a set use the add() method.

Add Sets
To add items from another set into the current set, 
use the update() method.

Example
Add elements from tropical into thisset:

thisset = {"apple", "banana", "cherry"}
tropical = {"pineapple", "mango", "papaya","apple"}

thisset.update(tropical)

print(thisset)





Add Any Iterable
The object in the update() method does not have to be a set, 
it can be any iterable object (tuples, lists, dictionaries etc.).

Example
Add elements of a list to at set:

thisset = {"apple", "banana", "cherry"}
mylist = ["kiwi", "orange"]

thisset.update(mylist)

print(thisset)



Example
Add an item to a set, using the add() method:

thisset = {"apple", "banana", "cherry"}
thisset.add("orange")
print(thisset)



Remove Item
To remove an item in a set, use the remove(), or the discard() method.

Example
Remove "banana" by using the remove() method:

thisset = {"apple", "banana", "cherry"}

thisset.remove("banana")

print(thisset)




#Remove "banana" by using the discard() method:

thisset = {"apple", "banana", "cherry"}

thisset.discard("banana")

print(thisset)


thisset = {"apple", "banana", "cherry",1,2,3}

for x in thisset:
  print(x)


thisset = {"apple", "banana", "cherry"}

print("banana" in thisset)

'''

thisset = {"apple", "banana", "cherry",1,2,3}
thisset.pop()
print(thisset)
