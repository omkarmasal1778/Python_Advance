'''
Object
Object is having states and behaviours in which state means what
does it has and behaviour means what does it do. for eg.
a pen has states:ink,nib,needle,cap etc.
          Behaviors:writing.

         *object is an instance of a class.
         *object comprises both  data members and methods.
         *Object is created from a class.

Class
*It is a collection of data members and member functions.
*Data members are the variable used inside class.
*Member functions are the function used inside class.
*It is also called userdefined data type.
*class keyword is used to create class.


Python Classes/Objects
Python is an object oriented programming language.
Almost everything in Python is an object, with its properties and methods.

#creating class

class student:
    #defining class variables
    name="Rocky"
    roll=5
s1=student()
print(s1.name)


#here student is class and name and roll are variables.


class MyClass:
    x = 5

print(MyClass)

#Create Object of class
#we can create object of class by using class name.
#There is no need of new keyword like java in python to create
#object.
#Syntax:
#    obj_name=class_name()

#Now we can use the class named MyClass to create objects:
#   for eg.
#  s1=student()



#Accessing variables of class
#We can access the variables of class by using dot(.) operator with object.
#We can also access function of a class by using dot(.) operator


#creating class
class student:
#defining class variables
 name="xyz"
 roll=5



#creating object

s1=student()
#accessing class variable
print("name:",s1.name)
print("roll no:",s1.roll)


#here to access a class variables inside function self keyword is
#used because self refers to the current class object.



class emp:
    id=5
    name="abc"
    def emp_fun(self):
        print("hello world")
        print("emp id is: ",self.id)
        print("emp name is: ",self.name)


obj=emp()  #creating an object
obj.emp_fun()   #calling function

class student:
    rollno=5
    name="abc"
    def fun1(self,per):
        print(self.rollno)
        print(self.name)
        print(per)

obj=student()
obj.fun1(45)



class emp:
    name="paresh"
    id=2
    def empfun(self):
        print("welcome to classes and obj")
        print(self.name)
        print(self.id)


obj=emp()

obj.empfun()




class MyClass:
    x = 5

obj = MyClass()
print(obj.x)



class Person:
    firstname="siya"
    lastname="jiya"
    age=30
    print("hello")

obj=Person()

print(obj.firstname)
print(obj.lastname)
print(obj.age)


class emp:
    id=5
    salary=3456
    def fun(self):
        print("welcome")
        print(self.salary)
        print(self.id)
obj=emp()
obj.fun()



class emp:
    name="abc"
    id=2
    def emp_fun(self):
        print("emp name is: ",self.name)
        print("emp id is: ",self.id)

obj=emp()
obj.emp_fun()


#class with variable and function
#creating class

class student:
#defining class variables
    roll=int(input("enter roll no"))
    name=input("enter name")
    marks=int(input("enter marks"))
    #defining function
    def showinfo(self):
        print("name:",self.name)
        print("roll no:",self.roll)
        print("marks:",self.marks)

    #creating object
s1=student()
#calling function of class
s1.showinfo()



class stud():
    roll=int(input("enter roll no"))
    name=input("enter name")
    def show(self):
        print("stud roll no is: ",self.roll)
        print("stud name is: ",self.name)
o=stud()
o.show()

class Student:
    roll_num = 101
    name = "Joseph"


    def display(self):
        print("student roll no is:",self.roll_num,"\n","stud name is:",self.name)

st = Student()
st.display()
'''