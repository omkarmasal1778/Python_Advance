'''
#Change List Items
Change Item Value

To change the value of a specific item, refer to the index number:

#Change the second item:

thislist = ["apple", "banana", "cherry"]
thislist[1] = "blackcurrant"
print(thislist)
'''

#Change a Range of Item Values
thislist = ["apple", "banana", "cherry", "orange", "kiwi", "mango"]
thislist[1:4] = ["blackcurrant", "watermelon"]
print(thislist)

'''



thislist = ["apple", "banana", "cherry"]
thislist[1:2] = ["blackcurrant",  "watermelon"]
print(thislist)


#Change the second and third value by replacing it with one value:
thislist = ["apple", "banana", "cherry"]
thislist[0:3] = ["watermelon","mango"]
print(thislist)


#Insert Items
To insert a new list item, without replacing any of the existing values,
we can use the insert() method.

The insert() method inserts an item at the specified index:

'''
thislist = ["apple", "banana", "cherry"]

thislist.insert(1, "watermelon")

print(thislist)
'''
#Python - Add List Items
#Append Items



#Using the append() method to append an item:

thislist = ["apple", "banana", "cherry"]
thislist.append("orange")
print(thislist)



thislist = ["apple", "banana", "cherry"]
thislist.insert(1, "orange")
print(thislist)


#Extend List
#Add the elements of tropical to thislist:
'''
thislist = ["apple", "banana", "cherry"]
tropical = ["mango", "pineapple", "papaya"]
thislist.extend(tropical)
print(thislist)
'''

#Remove List Items
Remove Specified Item

The remove() method removes the specified item.

thislist = ["apple", "banana", "cherry"]
thislist.remove("apple")
print(thislist)



#Remove the second item:
'''
thislist = ["apple", "banana", "cherry"]
thislist.pop()
print(thislist)

'''
#Remove the last item:

thislist = ["apple", "banana", "cherry"]
thislist.pop()
print(thislist)



thislist = ["apple", "banana", "cherry"]
del thislist
print(thislist)


li= ["apple", "banana", "cherry"]
del li
print(li)

'''
thislist = ["apple", "banana", "cherry"]
thislist.clear()
print(thislist)

'''

#Sort List Alphanumerically
List objects have a  sort()
method that will sort the list alphanumerically, ascending, by default:


thislist = ["orange", "mango", "kiwi",  "pineapple", "banana"]
thislist.sort()
print(thislist)


thislist = [100, 50, 65, 82, 23]
thislist.sort()
print(thislist)


#Sort Descending
To sort descending, use the keyword argument reverse = True:

'''
thislist = ["orange", "mango", "kiwi",  "pineapple", "banana"]
thislist.sort(reverse = True)
print(thislist)
'''

thislist = [100, 50, 65, 82, 23]
thislist.sort(reverse = True)
print(thislist)



#Reverse Order
The reverse() method reverses the current sorting order of the elements

thislist = ["banana", "Orange", "Kiwi", "cherry"]
thislist.reverse()
print(thislist)


#Copy a List
#Make a copy of a list with the copy() method:
'''
thislist = ["apple", "banana", "cherry"]
mylist  = thislist.copy()
print(mylist)
print(thislist)
