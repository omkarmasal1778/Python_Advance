# Simple while
# Loop runs till the condition is True


v1 = 1
while v1 <= 10:
    print (v1)
    v1 += 1

'''
i = 11
while i <= 16:
  print(i)
  i += 1





i = 11
while i >= 6:
      print(i)
      i -= 1


# python break statement

i = 1
while i < 16:
          print(i)
          if i == 6:
            break
          i += 1


    # python continue statement
i = 0
while i < 20:
    i += 1
    if i % 2 ==0:
        continue
print(i)




# Terminate loop on a certain user input

v1 = 1
while v1 <= 10:
    v1 = int(input("Enter new v1: "))
    print("v1 modified to: " + str(v1))




# 'break' -> breaks out of loop, doesn't execute any statement after it
while 1:
    v1 = int(input('Enter the no='))
    if v1 == 100:
           break;
    print (v1)
'''
# 'continue' -> continues to next iteration, skips all statements after it for that iteration
# Note: When 'v1' < 100 the last print statement is skipped and the control moves to the next iteration
while 1:
        print("Iteration begins")
        v1 = int(input())
        if v1 == 100:
         break;
        elif v1 < 100:
            print("v1 less than 100")
            continue
        print("Iteration complete")