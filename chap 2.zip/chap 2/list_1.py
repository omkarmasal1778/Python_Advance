'''
#Python Lists
mylist = ["apple", "banana", "cherry",5,6.7]
print(mylist)








List

Lists are used to store multiple items i a single variable.


It is a collection of data of different datatypes.
It is used to store list of values.
A list is created by putting list of comma-sepearated values
between square brackets.
Value of list can be accessed using index number. it is always
start from 0.



abc = ["apple", "banana", "cherry","apple"]

print(abc[2])
print(abc)

List Items

#List items are ordered, changeable, and allow duplicate values.

#List items are indexed, the first item has index [0], the second item has index [1] etc.

#*Ordered

#When we say that lists are ordered, it means that the items have a defined order,
#and that order will not change.

#If you add new items to a list, the new items will be placed at the end of the list.

#*Changeable

#The list is changeable, meaning that we can change, add,
#and remove items in a list after it has been created.




#Allow Duplicates
thislist = ["apple", "banana", "cherry", "apple","apple", "cherry",5,5.6]
print(thislist)



#List Length
#To determine how many items a list has, use the  len() function
'''
thislist = ["apple", "banana", "cherry"]
print(len(thislist))

'''

thislist = ["apple", "banana", "cherry"]
print(type(thislist) )

#List Items - Data Types
list1 = ["apple", "banana", "cherry"]
list2 = [1, 5, 7, 9, 3]
list3 = [True, False, False]

print(list1)
print(list2)
print(list3)



list1 = ["abc", 34, True, 40, "male"]
print(list1)
print(len(list1))
print(type(list1))







mylist = ["apple", "banana", "cherry"]
print(type(mylist))




#Python - Access List Items
#Access Items
#List items are indexed and you can access them by referring to the
#index number:




thislist = ["apple", "banana", "cherry"]
print(thislist[0]) #The first item has index 0.

# Negative Indexing
#Negative indexing means start from the end -1 refers to the last item, -2 refers to the second last item
#etc.

thislist = ["apple", "banana", "cherry"]
print(thislist[-1])



#Range of Indexes
#You can specify a range of indexes by specifying where to start and where to end the range.

#When specifying a range, the return value will be a new list with the specified items.
'''
thislist = ["apple", "banana", "cherry", "orange", "kiwi", "melon", "mango"]
print(thislist[2:5])
# The search will start at index 2 (included) and end at index 5 (not included).
'''


thislist = ["apple", "banana", "cherry", "orange",  "kiwi", "melon", "mango"]
print(thislist[:4])



thislist = ["apple", "banana", "cherry", "orange",  "kiwi", "melon", "mango"]
print(thislist[4:])



#Range of Negative Indexes
#Specify negative indexes if you want to start the search from the end
#of the list:
'''
thislist = ["apple", "banana", "cherry", "orange",  "kiwi", "melon", "mango"]
print(thislist[-4:-1])
'''

#Check if Item Exists
#To determine if a specified item is present in a list use the in keyword:




#Check if "apple" is present in the list:

thislist = ["apple", "banana", "cherry"]
if "apple" in thislist:
    print("Yes, 'apple' is in the fruits list")
else:
    print("no apple not in fruit list")


'''