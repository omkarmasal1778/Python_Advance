'''
try:
    a = int(input("Enter a:"))
    b = int(input("Enter b:"))
    c = a/b
    print(c)
except:
    print("Can't divide with zero")



try:
    a = int(input("Enter a:"))
    b = int(input("Enter b:"))
    c = a/b
    print("a/b = %d"%c)




# Using Exception with except statement. If we print(Exception) it will return exception class
except :
    print("can't divide by zero")

else:
    print("Hi I am else block")
'''