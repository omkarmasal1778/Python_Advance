class STUDENT:
    def __init__(self,NAME,ROLL_NO,M1,M2,M3):
        self.NAME=NAME
        self.ROLL_NO=ROLL_NO
        self.M1=M1
        self.M2=M2
        self.M3=M3
    def avg(self):
        total=self.M1+self.M2+self.M3
        avg=total//3
        percentage=(total/300)*100
        print("NAME-",self.NAME,"ROLL_NO-",self.ROLL_NO,"total->",total,"avg->",avg,"percentage->",percentage)
s1=STUDENT("shraddha",1,67,87,67)
s2=STUDENT("shreya",2,56,87,67)
s1.avg()
s2.avg()






