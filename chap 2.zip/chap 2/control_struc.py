#Python If ... Else
#Python Conditions and If statements
'''
•Equals: a == b
•Not Equals: a != b
•Less than: a < b
•Less than or equal to: a <= b
•Greater than: a > b
•Greater than or equal to: a >= b


# SIMPLE if Statement
#An "if statement" is written by using the if keyword.
#If exicute if condition related true part


b=int(input("enter b="))
if b > 18:
    print("b is greater than 18")
else:
    print("b is less than 18")



a=int(input("enter value for a"))
b=int(input("enter value for b"))

if b > a:
    print("b is greater than a")
else:
    print("a is greater than b")







a = 66
b = 33
if a > b:
    print("A")
else:
    print("B")


a = int(input("enter no"))
if a % 2 == 0:
    print("no is even")
else:
    print("no is odd")







        # Short Hand If

        # If you have only one statement to execute,
        # you can put it on the same line as the if statement.

        a = 29
        b = 33

        if a > b:
            print("a is greater than b")
        else:
            print("a is less than b")



#One line if else statement:
#short hand property
a = 27
b = 3
print("A") if a > b else print("B")



#One line if else statement, with 3 conditions:
a = 700
b = 700

print("A") if a > b else print("=") if a == b else print("B")






And

The and keyword is a logical operator, and is used to combine
conditional statements:





#Test if a is greater than b, AND if c is greater than a
a = 200
b = 33
c = 300
if a > b and c > a:
    print("Both conditions are True")


Or

The or keyword is a logical operator, and is used to
combine conditional statements:


a = 200
b = 33
c = 300
if a > b or c < a:
     print("Either one condition is True")



     age = int(input("Enter your age? "))
     if age >= 18:
         print("You are eligible to vote !!");
     else:
         print("Sorry! you have to wait !!");




#Elif
#The elif keyword is
#pythons way of saying "if the previous conditions were not true,
#then try this condition".


'''
a = 1
b = 1
if b > a:
    print("b is greater than a")
elif a == b:
    print("a and b are equal")
else:
    print("a is greater")

'''


#Else

#The else keyword catches anything which isn't caught by the preceding
#conditions.
a = 200
b = 200
if b < a:
    print("b is greater than a")
elif a == b:
    print("a and b are equal")
else:
    print("a is greater than b")






num = int(input("enter the number?"))
if num%2 == 0:
    print("Number is even")
else:
    print("number is odd")




    a = int(input("Enter a= "));
    b = int(input("Enter b= "));
    c = int(input("Enter c= "));
    if a > b and a > c:
        print("a is largest");

    if b > a and b > c:
        print("b is largest");
    if c > a and c > b:
        print("c is largest");



        number = int(input("Enter the number?"))
        if number == 10:
            print("number is equals to 10")
        elif number == 50:
            print("number is equal to 50");
        elif number == 100:
            print("number is equal to 100");
        else:
            print("number is not equal to 10, 50 or 100");






marks = int(input("Enter the marks? "))
if marks > 85 and marks <= 100:
   print("Congrats ! you scored grade A ...")
elif marks > 60 and marks <= 85:
   print("You scored grade B + ...")
elif marks > 40 and marks <= 60:
   print("You scored grade B ...")
elif (marks > 30 and marks <= 40):
   print("You scored grade C ...")
else:
   print("Sorry you are fail ?")





   Nested
   If

   You
   can
   have if statements
   inside if statements,
   this is called
   nested if statements.

x = 32
if x > 10:
    print("Above ten,")
    if x < 20:
        print("and also above 20!")
    else:
        print("but not above 20.")



        age = int(input("enter age"))

        if age >= 18:
            print("age is greater than 18")
            if age <= 40:
                print("eligible for job")
            else:
                print("but greater than 40")
        else:
            print("age is less than 18")








'''