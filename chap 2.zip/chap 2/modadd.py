# importing  module calc.py
import mod2

print(mod2.add(10, 2))
print(mod2.subtract(20,30))