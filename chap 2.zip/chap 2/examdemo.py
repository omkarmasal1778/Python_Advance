'''
import numpy as np
ar = np.array([3,2,0,1])
print(np.sort(ar))


import numpy as np
ar = np.array(['banana','cherry','apple'])
print(np.sort(ar))


import numpy as np
ar = np.array([True,False,True])
print(np.sort(ar))


import numpy as np
ar = np.array([[3,2,4],[5,0,1]])
print(np.sort(ar))



import numpy as np
ar = np.array([1,2,3,4,5,4,4])
x = np.where (ar == 4)
print(x)


import numpy as np
ar = np.array([1,2,3,4,5,6,7,8,2,6,10])
x = np.where (ar %2 ==0)
print(ar[x])


import numpy as np
ar = np.array([1,2,3,4,5,6,7,8,])
x = np.where (ar %2 ==1)
print(ar[x])


import numpy as np
arr = np.array([1,2,3,4,5,6,7,8,2,6,10])
newarr =np.array_split(arr,2)
print(newarr)


import numpy as np
arr = np.array([1,2,3,4,5,6,7,8,2,6,10])
newarr =np.array_split(arr,3)

print(newarr)
print(newarr[1])
print(newarr[2])

import numpy as np

arr = np.array([[1,2],[3,4],[5,6],[7,8],[9,10],[11,12]])
print(arr)
newarr=np.array_split(arr,3)
print(newarr[0][1][0])
print(newarr[1][0][0])
print(newarr)
'''