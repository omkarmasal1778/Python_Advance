x = frozenset({"apple", "banana", "cherry"})

#display x:
print(x)

#display the data type of x:
print(type(x))




fs = frozenset({1, 2, 3})
cp = fs.copy()
print(fs)
print(cp)



