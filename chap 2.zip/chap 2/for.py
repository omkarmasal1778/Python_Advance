'''
Python For Loops
A for loop is used for iterating over a sequence (that is either
                a list, a tuple, a dictionary, a set, or a string).

This is less like the for keyword in other programming languages, and
works more like an iterator method as found in other
object-orientated programming languages.





#The range() Function
#To loop through a set of code a specified number of times, we can use
#the range() function,

for x in range(5):
 print(x)


for x in range(8, 12):
    print(x)


# for loop --> (start,end-1,step)
for i in range(2, 10):
         print(i)

for x in range(7, 70, 2):
    print(x)

#for loop for odd numbers
for i in range(1,20,2):
    
    print(i)

    # for loop for even numbers
    for i in range(0, 20, 2):
        print(i)



        # for loop for reversed numbers

for i in reversed(range(10 + 1)):
         print(i)

'''
        # for loop for reversed numbers
for i in range(11, -1, -2):
        print(i)


'''


#Else in For Loop
for x in range(6):
    print(x)
else:
    print("Finally finished!")
for i in range(1, 3):
    for j in range(1, 7):
        print(j, end="  ")
        print(i,end='')
'''
'''for i in range(1, 6):
            for j in range(1, 6):
                if j <= i:
                    print("* ", end=" ")
                else:
                    print(" ", end=" ")

        

for i in range(1, 5):
    for j in range(1, 5):
        if i<=5:
            if j<=5:
             print("*\t",end='')
            print('')


i=1
while i<=5:
    j=1
    while j<=5:
        print('*',end='')

        j+=1
    print('')
    i+=1


i = 2

while i <= 50:

    j = 2
    while j < 50:
        if i%j == 0:
            break
        j += 1
    if i == j:
        print(i,end=' ')
    i += 1
'''