a = int(input("enter the no:"))
if a > 0:
    print("positive no:")
else:
    print("negative no:")
