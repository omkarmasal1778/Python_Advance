'''
Python File Open
File handling is an important part of any web application.

Python has several functions for creating,
reading, updating, and deleting files.
File Handling
The key function for working with files in Python is the open() function.

The open() function takes two parameters; filename, and mode.

There are four different methods (modes) for opening a file:

"r" - Read - Default value. Opens a file for reading, error if the file does
             not exist

"a" - Append - Opens a file for appending, creates the file if it does not exist

"w" - Write - Opens a file for writing, creates the file if it does not exist

"x" - Create - Creates the specified file, returns an error if the file exists


f = open("f1.txt", "x")


#Syntax
#To open a file for reading it is enough to specify the name of the file:

f = open("abc.txt")
print(f.read())

#The code above is the same as:

f = open("abc.txt", "rt")
print(f.read())

#Because "r" for read, and "t" for text are the default values, you do not need to specify them.
f = open("abc.txt", "rt")

print(f.read())


f = open("abc.txt", "r")

print(f.read())
f = open("abc.txt", "r")

print(f.read(15))

#Read Lines
#You can return one line by using the readline() method:

f = open("abc.txt", "r")
print(f.readline())
print(f.readline())

#print(f.readline())
#Read Lines
#You can return one line by using the readline() method:

f = open("abc.txt", "r")
for x in f:
    print(x)
#Read Lines
#You can return one line by using the readline() method:

f = open("abc.txt", "r")
print(f.readline())
print(f.readline())

f.close()



f = open("f1.txt","w")

f.write("hellow good afternoon everybody\n"
        "hello world")
f.close()


f = open("abc.txt", "r")
print(f.read())
f.close()

#Write to an Existing File

f = open("abc.txt", "w")
f.write("Now the file has more content!")
f.close()



#open and read the file after the appending:
f = open("abc.txt", "r")
print(f.read())


f = open("abc.txt", "w")
f.write("Woops! I have deleted the content!")
f.close()

#open and read the file after the appending:

f = open("abc.txt", "r")
print(f.read())
f.close()



#Python Delete File
import os
os.remove("hey.txt")




Write to an Existing File
To write to an existing file, you must add a parameter to the open() function:

"a" - Append - will append to the end of the file

"w" - Write - will overwrite any existing content

f = open("abc.txt", "w")
f.write("wow! python batchWhat is Python Python History Features of Python")
f.close()

#open and read the file after the appending:
f = open("abc.txt", "r")
print(f.read())

f = open("abc.txt", "a")
f.write(" Now the file has more content!")
f.close()

#open and read the file after the appending:
f = open("abc.txt", "r")
print(f.read())



import os
os.rmdir("D:\\hello")

with open('app.log', 'w', encoding = 'utf-8') as f:
   #first line
   f.write('my first file\n')
   #second line
   f.write('This file\n')
   #third line
   f.write('contains three lines\n')

with open('app.log', 'r', encoding = 'utf-8') as f:
   content = f.readlines()

for line in content:
   print(line)

import os
os.rename("abc.txt", "abc1.txt")
'''