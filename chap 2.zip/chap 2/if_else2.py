a=int(input("enter value of a:"))
b=int(input("enter value of b:"))
c=int(input("enter value of c:"))
if a>b:
    if a>c:
        print("A is greater ")
    else:
        print("C is greater ")
elif b>c:
    print("B is greater ")
else:
    print("C is greater ")