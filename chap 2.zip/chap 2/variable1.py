name="tom"
rollno=5
print("name is:",name)
print("roll number is:",rollno)
