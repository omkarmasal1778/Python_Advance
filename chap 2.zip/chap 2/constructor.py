
'''
  Python Constructor
A constructor is a special member function of class that executes
when we create the instance(object) of that class.
is used to initialize the instance members of the class.

In C++ or Java, the constructor has the same name as its class,
but it treats constructor differently in Python. It is used to create
an object.

Constructors can be of two types.

Parameterized Constructor
Non-parameterized Constructor

Constructor definition is executed when we create the object of this
class.
Constructors also verify that there are
enough resources for the object to perform any start-up task.


class stud:
    def stud_fun(self,rollno,name):
        self.rollno=rollno
        self.name=name
        print("hello")
        print(self.rollno)
        print(self.name)
s1=stud()
s1.stud_fun(2,"RAJ")    #calling of function


Creating the constructor in python
In Python, the method the __init__() simulates the constructor of the
class.
This method is called when the class is instantiated. It accepts the
self-keyword as a first argument which allows accessing the attributes
or method of the class.
The __init__() Function

All classes have a function called __init__(), which is always
executed when the class is being initiated.

Use the __init__() function to assign values to object properties, or
other operations
that are necessary to do when the object is being created:
Python Parameterized Constructor
The parameterized constructor has
multiple parameters along with the self. Consider the following example.

class student:
    #creating parameterised constructor
        def __init__(self,name,roll):
            self.name = name
            self.rollno = roll

            print("name is:",name)
            print("Rollno:",roll)
#creting object

s1=student("ayushi",5)
s2=student("xyz",10)



class stud:
    roll=5
    name="abc"
    def __init__(self):
        print("roll is:",self.roll)
        print("name is:",self.name)


s=stud()

class Person:
    def __init__(self,name,age):
        self.name = name
        self.age = age

p1 = Person("John", 36)

print(p1.name)
print(p1.age)


class details:
    def __init__(self,name,age):
        self.name=name
        self.age=age

    def display(self):
        print("hello my name is:" , self.name )
        print("my age is:",self.age)


o=details("Reema" ,30)
o.display()


class Employee:
    def __init__(self, name, id):
        self.id = id
        self.name = name

    def display(self):
        print("ID: %d \nName: %s" % (self.id, self.name))


emp1 = Employee("John", 101)
emp2 = Employee("David", 102)
emp1.display()
emp2.display()


Counting the number of objects of a class
The constructor is called automatically
when we create the object of the class. Consider the following example.
'''
class Student:
    count = 0
    def __init__(self):
        Student.count = Student.count + 1
s1=Student()
s2=Student()
s3=Student()
s4=Student()
print("The number of students:",Student.count)
'''


#Python Non-Parameterized Constructor
The non-parameterized constructor uses when we do not want to manipulate the
value or
the constructor that has only self as an argument. Consider the following example.


class student:
    #creating non_parameterised constructor
    def __init__(self):
        print("hi i am non parameterised constructor")

    def info(self):
        print("name:Aayushi")
        print("rollno:305")
s1=student()
s1.info()


class emp:
    def __init__(self):

        self.id=int(input("enter id"))
        self.name=input("enter emp name")

    def fun1(self):
        print("id is:",self.id)
        print("name is:",self.name)
obj=emp()
obj.fun1()



class constr:
    def __init__(self):
        print("hello this is constructor, it executes when u create an object")
    def fun(self):
        print("this is regular member fun")

c=constr()
c.fun()


class Student:
    # Constructor - non parameterized
    def __init__(self):
        print("This is non parametrized constructor")
    def show(self,name):
        print("Hello",name)
Student = Student()
Student.show("John")


class Student:

    # Constructor - parameterized
    def __init__(self, name):
        print("This is parametrized constructor")
        self.name = name
    def show(self):
        print("Hello",self.name)
student = Student("John")
student.show()
'''