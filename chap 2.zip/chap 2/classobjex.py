'''
class details:
    def __init__(self):
        self.name=""
    def accept(self):
        self.name=input("enter your name")
        print("name is:"+self.name)
    def display(self):
        print(self.name)
d=details()
d.accept()
d.display()




class Dog:

    def __init__(self, name, age):
        self.name = name
        self.age = age

    #def bark(self):
     #   print("bark bark!")

    def doginfo(self):
        print(self.name + " is " + str(self.age) + " year(s) old.")

ozzy = Dog("Ozzy", 2)
skippy = Dog("Skippy", 12)
filou = Dog("Filou", 8)



ozzy.doginfo()
skippy.doginfo()
filou.doginfo()



class Student:
    student_id = 'V10'
    student_name = 'Jacqueline Barnett'
    def display(self):
        print("Student id:",Student.student_id,"\nStudent Name:",Student.student_name)
        print("Original attributes and their values of the Student class:")
#Student.display()
d=Student()
d.display()




class Person:
    def __init__(self):
        self.firstname = input('Enter first name:  ')
        self.lastname = input('Enter last name:  ')

    def show_full_name(self):
        print( self.firstname + ' ' + self.lastname)


# creating an object with the class
person2 = Person()
person2.show_full_name()



#Write a Python class named Rectangle constructed by a
#length and width and a method which will compute the area of a rectangle.
class Rectangle():
    def __init__(self, l, w):
        self.length = l
        self.width  = w

    def rectangle_area(self):
        return self.length*self.width

newRectangle = Rectangle(12, 10)
print(newRectangle.rectangle_area())




class Vehicle:

    def __init__(self, name, max_speed, mileage):
        self.name = name
        self.max_speed = max_speed
        self.mileage = mileage

School_bus = Vehicle("School Volvo", 180, 12)
print("Vehicle Name:",School_bus.name, "Speed:",School_bus.max_speed, "Mileage:", School_bus.mileage)
'''