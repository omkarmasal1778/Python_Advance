'''
There are four different methods (modes) for opening a file:

"r" - Read - Default value. Opens a file for reading, error if the file does
             not exist

"a" - Append - Opens a file for appending, creates the file if it does not exist

"w" - Write - Opens a file for writing, creates the file if it does not exist

"x" - Create - Creates the specified file, returns an error if the file exists

#create a file

f = open("file12.txt", "x")




#Write to an Existing File

f = open("file12.txt","w")

f.write("Disha computer institute\n"
        "Rajarampuri\n"
        "kolhapur\t""jaysingpur")
f.close()



#To open a file for reading it is enough to specify the name of the file:
#read content

f = open("file12.txt", "r")
print(f.read())
f.close()


f = open("file12.txt", "a")
f.write("\nNow the file has more content!")
f.close()

#open and read the file after the appending:


f = open("file12.txt", "r")
print(f.read())


#Python Delete File

import os
os.remove("file12.txt")


#Syntax
#Because "r" for read, and "t" for text are the default values, you do not need to specify them.


#The code above is the same as:

f = open("file12.txt", "rt")
print(f.read())



f = open("file1.txt", "r")

print(f.read(12))

#Read Lines
#You can return one line by using the readline() method:

f = open("file12.txt", "r")

print(f.readline())
print(f.readline())
#print(f.readline())


#Read Lines
#You can return one line by using the readline() method:

f = open("file12.txt", "r")
for x in f:
    print(x)
'''




