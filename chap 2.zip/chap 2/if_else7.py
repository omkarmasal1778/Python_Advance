name=str(input("Enter the name of student: "))
num=int(input("Enter the roll number of student: "))
m1=int(input("Enter the 1st subject marks: "))
m2=int(input("Enter the 2nd subject marks: "))
m3=int(input("Enter the 3rd subject marks: "))
m4=int(input("Enter the 4th subject marks: "))
m5=int(input("Enter the 5th subject marks: "))
total=m1+m2+m3+m4+m5
per=total/5
print("\n****STUDENT REPORT***")
print("Name:",name)
print("Roll no:",num)
print("total marks:",total)
print("Percentage:",per)
if per>85 and per<100:
    print("Congrats!!! you scored A grade")
elif per>60 and per<=85:
    print("you scored B grade ")
elif per>40 and per<=60:
    print("you scored C grade ")
else:
    print("sorry you are fail ")
    