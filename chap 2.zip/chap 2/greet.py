import module as m

m.greeting("Atharv")
