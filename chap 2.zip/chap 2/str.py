#Python Strings

'''
Strings
Strings in python are surrounded by either single quotation marks,
or double quotation marks.

'hello' is the same as "hello".


print("Hello")
print('Hello')




Assign String to a Variable
Assigning a string to a variable
is done with the variable name followed
by an equal sign and the string:




a = "Hello"
print(a)



#Multiline Strings
#You can assign a multiline string to a variable by using three quotes:

a =Lorem ipsum dolor sit amet,consectetur adipiscing elit,
sed do eiusmod tempor incididuntut labore et dolore magna aliqua
print(a)






# Adding WhiteSpaces
print ("disha\ncomputer\npython")
print ("disha\tcomputer\tpython")
print ("disha\tcomputer\npython")



Strings are Arrays
Like many other popular programming languages,
strings in Python are arrays of bytes representing
unicode characters.

However, Python does not have a character data type,
a single character is simply a string with a length of 1.

Square brackets can be used to access elements of the string.



a = "Hello,World!"
print(a[7])



Looping Through a String
Since strings are arrays,
we can loop through the characters in a string,
with a for loop.


from fontTools.misc.plistlib import end_string

for x in "banana":
    print(x)


#    Check String To check if a certain phrase or character is present in a string,we can use the keyword in.

txt = "The best things in life are free!"
print("one" in txt)





txt = "The best things in life are free!"
if "free" in txt:
    print("Yes, 'free' is present.")
else:
    print("no")




Check if NOT

txt = "The best things in life are free!"
print("best" not in txt)




txt = "The best things in life are free!"
if "best" not in txt:
    print("No, 'expensive' is NOT present.")
else:
    print("it present")


    # Python - Slicing Strings Slicing You can return a range of characters by using the slice syntax.

    Specify the start index and the end index, separated by a colon, to return a
    part of the string.


b = "Hello, World!"
print(b[1:4])


To check if a certain phrase or character is
NOT present in a string, we can use the keyword not in.




b = "Hello, World!"
print(b[:5])




b = "Hello, World!"
print(b[2:])

b = "Hello, World!"
print(b[-6:-2])


#Python - Modify Strings
Python has a set of built-in methods that you can use on string





#The upper() method returns the string in upper case:

a = "Hello, World!"
print(a.upper())






#The lower() method returns the string in lower case:

a = "Hello, World!"
print(a.lower())






Remove Whitespace
Whitespace is the space before and/or after the actual text,
and very often you want to remove this space.




#The strip() method removes any whitespace from the beginning or the end:

a = "       Hello, World!      "
print(a)
print(a.strip()) # returns "Hello, World!"


#The replace() method replaces a string with another string:
a = "Hello, WHrld!"
print(a.replace("H","J"))





Split String
The split() method returns a list where the text
between the specified separator becomes the list items.





a = "Hello World! welcome"
print(a)
print(a.split(" ")) # returns ['Hello', ' World!']


String Concatenation
To concatenate, or combine, two strings you can use the + operator.





a = "hello"
b = "world"
c = a + b
print(c)  #helloworld




a = "Hello"
b = "World"
c = a + " " + b #hello world
print(c)




String Format
As we learned in the Python Variables chapter,
we cannot combine strings and numbers like this:


age = 36
txt = "My name is John, I am " + str(age)
print(txt)




The format() method takes the passed arguments, formats them, and places
them in the string where the placeholders {} are:

Example
Use the format() method to insert numbers into strings:


a=20
print(f"value of {a} is int ")



age = 36
txt = "My name is John and I am {} "
print(txt.format(age))

'''
import string

print ("All Letters:   " + string.ascii_letters)
print ("Lowecase:      " + string.ascii_lowercase)
print ("Uppercase:     " + string.ascii_uppercase)
print ("Punctuations:  " + string.punctuation)
print ("Numbers:       " + string.digits)
print ("Hex Digits:    " + string.hexdigits)
print ("Oct Digits:    " + string.octdigits)
print ("Whitespace:    " + string.whitespace)
print ("Printable:     " + string.printable)


