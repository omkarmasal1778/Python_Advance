a=int(input("enter value of A:"))
b=int(input("enter value of B:"))
c=int(input("enter value of C:"))
if a>b and a>c:
    print("A is greater no")
elif b>a and b>c:
    print("B is greater no")
elif c>a and c>b:
    print("C is greater no")
elif a==b and b==c and c==a:
    print("all no are equal")
else:
    print("two no are equal")
