import string

print ("All Letters:   " + string.ascii_letters)
print ("Lowecase:      " + string.ascii_lowercase)
print ("Uppercase:     " + string.ascii_uppercase)
print ("Punctuations:  " + string.punctuation)
print ("Numbers:       " + string.digits)
print ("Hex Digits:    " + string.hexdigits)
print ("Oct Digits:    " + string.octdigits)
print ("Whitespace:    " + string.whitespace)
print ("Printable:     " + string.printable)


