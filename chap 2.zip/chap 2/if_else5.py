number =int(input("Enter a number: "))
if number == 10:
    print("The number is equal to 10")
elif number == 50:
    print("The number is equal to 50")
elif number == 100:
    print("The number is equal to 100")
else:
    print("The number is not equal to 10,50,100")
