#Splitting NumPy Arrays

#Splitting is reverse operation of Joining.

#Joining merges multiple arrays into one and Splitting breaks one array into multiple.

#We use array_split() for splitting arrays, we pass it the array we want to split and
#the number of splits.
'''
#Split the array in 3 parts:
import numpy as np

arr = np.array([1, 2, 3, 4, 5, 6, 7,8])

newarr =  np.array_split(arr, 2)

print(newarr)

#Access the splitted arrays:

import numpy as np

arr = np. array([1,2,3, 4, 5, 6])

newarr =  np.array_split(arr, 3)
print(newarr)
print(newarr[1])
print(newarr[2])
print(newarr[0])


'''
#Splitting 2-D Arrays
#Split the 2-D array into three 2-D arrays.

import numpy as np

arr = np.array([[1, 2], [3, 4], [5, 6], [7, 8], [9,  10], [11, 12]])
print(arr)
newarr = np.array_split(arr, 3)
print(newarr)
print(newarr[0][1][0])
print(newarr[1][0][1])

