a=int(input("Enter no"))
if a%2==0:
    print(" no is Even")
else:
    print(" no is Odd")