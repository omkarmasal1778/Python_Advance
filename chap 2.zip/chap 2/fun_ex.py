'''
def fun():
    print("Inside function")
    print("hello")
fun()
'''

'''
#Parameterized Function

def evenOdd( x ):
    if (x % 2 == 0):
        print("even")
    else:
        print("odd")

evenOdd(7)
evenOdd(4)

'''

#Default arguments
def myFun(x, y = 50):
    print("x: ", x)
    print("y: ", y)
myFun(2,4)
myFun(3)
'''



def sum(a,b):
    total = a + b
    return total

x = 10
y = 20
print(sum(2,3))
print("The sum of",x,"and",y,"is:",sum(x, y))



# Example 10
def add():                            #local variable x
 x=50
 y=30
 z=x+y
 print("add=",z)
#calling function
add()





Global variable
A variable which is created outside a function is called
global variable.
It can be used anywhere in the programm.


x=5
y=3
def add():
    #accessing global variable inside a function
    print("inside function sum=",x+y)

#calling a function
def demo():
    print("sub:",x-y)
add()
demo()


#accessing global variable  outside a function
print("outside function sum=",x+y)
#local and global variable with same name



#creating global variable
x=50
def add():
    x=20
    print("inside function x=",x)

add()
print("outside function x=",x)




global keyword
simply we cant modify the value of global variable inside a
function but by using global keyword we can modify the value of global
variable inside a function


x=50
def add():
    global x
    #updating value of x
    x=20
    print("inside function x=",x)
add()

print("outside function x=",x)



x = 3
def func(a):
    global x
    x = 5                      # global variable
    return x * a
print(func(5))
print(x)





def add():
    a=int(input("Enter the number 1 : "))
    b=int(input("Enter the number 2 : "))
    print("Add =",a+b)
def sub():
    a = int(input("Enter the number 1 : "))
    b = int(input("Enter the number 2 : "))
    print("sub=",a-b)

add()
sub()
'''