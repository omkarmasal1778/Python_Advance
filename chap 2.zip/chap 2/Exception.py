#Exception Handling
#When an error occurs, or exception as we call it,
#Python will normally stop and generate an error message.
#The try block lets you test a block of code for errors.
#The except block lets you handle the error.
#The finally block lets you execute code,
#regardless of the result of the try- and except blocks.
#The try block will generate an error, because x is not defined:
'''
#b=2

try:
  print(b)
except:
    print("An exception occurred")

    
#Many Exceptions

try:
    print(j)
except:
    print("variable is not defined")



Else
You can use the else keyword to define a block of
code to be executed if no errors were raised:

l=5
try:
  print(l)
except:
  print("Something went wrong")
else:
  print("Nothing went wrong")

try:
    a=10
    print("value of x:",a)
except:
    print("an exception occured")
else:
    print("this is else statement")

try:
    a=10
    b=2
    c=a/b
    print("value of c",c)
except:
    print("dont put zero in denominator")
else:
    print("this is else statement")

'''
#Finally
#The finally block, if specified, will be executed
#regardless if the try block raises an error or not.
'''
try:
  print(o)
except:
  print(" Something went wrong")
finally:
  print("The 'try except' is finished")

j=2
try:
  print(j)
except:
  print("Something went wrong")
finally:
  print("The 'try except' is finished")


try:
    a=10
    b=2
    c=a/b
    print("value of c:",c)
except:
    print("dont put zero indenominator")
else:
    print("this is else statement")
finally:
    print("this is finally block")


'''

