
'''Python Operators
Operators are special symbol which is
used to perform operations on variables and values.

Operand
It is a data or variable on which the operation is to be performed


Types of Operator:

Arithmetic operators
Relational Operators
Logical operators
Assignment operators
Bitwise operators
Membership operators
Identity operators


Python Arithmetic Operators
Arithmetic operators are used with
numeric values to perform common mathematical operations:

Operator	Name	Example
+        Addition	    x + y
-      Subtraction	    x - y
*     Multiplication	x * y
/        Division	    x / y
%        Modulus	    x % y
**   Exponentiation	   x ** y


Python Assignment Operators
Assignment operators are used to assign values to variables:
    Operator	Example	Same As

    Symbol       Example       Same as
      =            x=y            x=y
      +=          x+=y            x=x+y
      -=          x-=y            x=x-y
      *=          x*=y            x=x*y
      /=          x/=y            x=x/y
      %=          x%=y            x=x%y
    **=           x**=y           x=x**y






Python Relational Operators
Operator	Name	Example	Try it
==         Equal     x == y
!=       Not equal   x != y
>       Greater than x > y
<        Less than   x < y
>=    Greater than or equal to   x >= y
<=    Less than or equal to      x <= y



Python Logical Operators
Logical operators are used to combine conditional statements:

Operator	Description	Example	Try it
and 	Returns True if both statements are true
x < 5 and  x < 10
or	Returns True if one of the statements is true
x < 5 or x < 4
not	Reverse the result, returns False if the result is true	not
(x < 5 and x < 10)




Python Identity Operators
Identity operators are used to compare the objects,
not if they are equal, but if they are actually the same
object, with the same memory location:
Operator	Description	Example
is 	        Returns True if both variables are the same object
      x is y
is not	     Returns True if both variables are not the same object
x is not y

#example

x = ["apple", "banana"]
y = ["apple", "banana"]
z = x
print(x is z)# returns True because z is the same object as x
print(x is y)# returns False because x is not the same object as y, even if they have the same content
print(x == y)# to demonstrate the difference betweeen "is" and "==": this comparison returns True because x is equal to y

#Python Membership Operators
Membership operators are used
to test if a sequence is presented in an object:

Operator	Description	Example
in
Returns True if a sequence with the specified value is present in the object
x in y
not in	Returns True if a sequence with the specified value is not present in the object
x not in y
'''
#Examples
x = ["apple", "banana"]

print("apple" in x)
'''
# returns True because a sequence with the value "banana" is in the list



'''
x = ["apple", "banana"]

print("cherry" not in x)
'''
# returns True because a sequence with the value "pineapple" is not in the list
#
#
# '''