'''
a=10
b=20
print('addition =',a+b)
'''

a=10
b=20
c=a+b
print('addition =',c)
