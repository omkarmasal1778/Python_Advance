
n=str(input("enter the name of student:"))
r=int(input('enter the roll no:'))
m1=int(input("marks of m1:"))
m2=int(input("marks of m2:"))
m3=int(input("marks of m3:"))
m4=int(input("marks of m4:"))
m5=int(input("marks of m5:"))
total=int(m1+m2+m3+m4+m5)
per=total/5.0
print("---student record---")
print("name of student:",n)
print("roll no:",r)
print("total:",total)
print("percentage:",per)


