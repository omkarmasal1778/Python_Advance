r=int(input("enter the radius:"))
area=3.14*r*r
print("area of circle:",area)
















a = int(input("Enter the number: "))
b = float(input("Enter the decimal number: "))
c = str(input("Enter the string: "))
print(a)
print(b)
print(c)
