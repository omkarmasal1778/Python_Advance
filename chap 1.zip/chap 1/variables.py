"""variable
it is a name of storage space which is used to store data.
Its value maybe changes.
It always contains last value stored to it.
Variable is created by assigning a value to it.

Variable initialization

name="tom"
rollno=5

here rollno and name are the name of variables.
value of name is tom, rollno is 5

Printing value of variable
we can print value of a variable using print() function.




Rules to define a variable
The first letter of a variable should be alphabet or underscore(_)
The first letter of a variable should not be digit.
After first character it may be combination of alphabets and digits.
Blank space are not allowed in variable name.
variable name should not be keyword.
Variable names are case sensitive. for eg. marks and MARKS are
  different variables.
"""










#creating variable
name="tom"
rollno=5

#printing value of variable
print("name is:",name)
print("roll number is:",rollno)