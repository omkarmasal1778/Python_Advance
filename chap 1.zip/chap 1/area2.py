b=int(input("Enter the base="))
h=int(input("Enter the height="))
area=0.5*b*h
print("Area of triangle=",area)
