a=int(input("enter the value of A:"))
b=int(input("enter the value of B:"))
print("before swapping")
print("A:",a ,"\t B:",b)
c=a
a=b
b=c
print("after swapping")
print("A:",a ,"\t B:",b)