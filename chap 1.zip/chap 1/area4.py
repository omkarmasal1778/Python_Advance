l=int(input("enter the length:"))
b=int(input("enter the breadth:"))
area=l*b
print("area of rectangle:",area)



