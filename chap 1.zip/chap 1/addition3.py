a=int(input("Enter the 1 value="))
b=int(input("Enter the 2 value="))
c=a+b
print("Addition=",c)
c=a-b
print("Subtraction=",c)
c=a*b
print("Multiplication=",c)
c=a/b
print("Divion=",c)