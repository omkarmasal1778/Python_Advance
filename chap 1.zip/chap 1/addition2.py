a=int(input("enter the no a:"))
b=int(input("enter the no b:"))
c=a+b
print("addition:",c)
