#Swapping using two variable
a=int(input("Enter value of a="))
b=int(input("Enter value of b="))
print("Before swapping")
print("A:",a,"\tB:",b)
a=a+b
b=a-b
a=a-b
print("After swapping")
print("A:",a,"\tB:",b)