'''a=int(input('Enter the value of a='))
b=int(input('Enter the value of b='))
c=a+b
print("Addition=",c)

'''
r=int(input('Enter the radius='))
area=3.14*r*r
print('area of circle=',area)