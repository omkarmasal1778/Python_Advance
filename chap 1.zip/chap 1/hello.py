print("hello")




'''

















a=int(input("Enter  no1="))
b=int(input('Enter no2= '))
print('addition=',a+b)

a=50
b=30
c=a+b
print('addition=',c)


r=int(input('Enter the radius='))
area=3.14*r*r
print("area of circle= ",area)
'''