s=int(input("Enter the side length="))
area=s*s
print("Area of square=",area)



#single line comment
"""multi line comment"""
'''multi line comment'''




