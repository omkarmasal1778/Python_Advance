from random import randrange as rg
print (rg(23,32))